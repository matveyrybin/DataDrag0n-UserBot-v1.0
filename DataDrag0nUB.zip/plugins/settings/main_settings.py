"""Please, ignore this file."""

version = "1.1.2.0"
module_list = {}
file_list = {}